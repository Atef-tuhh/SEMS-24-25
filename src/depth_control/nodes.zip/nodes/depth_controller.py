#!/usr/bin/env python3
"""
This node is your depth controller.
It takes as input a current depth and a given depth setpoint.
Its output is a thrust command to the BlueROV's actuators.
"""

import rclpy
from hippo_control_msgs.msg import ActuatorSetpoint
from hippo_msgs.msg import DepthStamped, Float64Stamped
from rclpy.node import Node


class DepthControlNode(Node):

    def __init__(self):
        super().__init__(node_name='depth_controller')

        # Initialize control variables
        self.current_setpoint = 0.0
        self.current_depth = 0.0
        self.last_error = 0.0
        self.integral = 0.0
        self.last_time = self.get_clock().now()

        # Declare ROS parameters for PID gains
        self.declare_parameter('K_p', 10.0)  # Proportional gain
        self.declare_parameter('K_i', 0.7)  # Integral gain
        self.declare_parameter('K_d', 2.0)  # Derivative gain

        # Publisher and subscriptions
        self.thrust_pub = self.create_publisher(msg_type=ActuatorSetpoint,
                                                topic='thrust_setpoint',
                                                qos_profile=1)

        self.setpoint_sub = self.create_subscription(
            msg_type=Float64Stamped,
            topic='depth_setpoint',
            callback=self.on_setpoint,
            qos_profile=1,
        )
        self.depth_sub = self.create_subscription(
            msg_type=DepthStamped,
            topic='depth',
            callback=self.on_depth,
            qos_profile=1,
        )

    def on_setpoint(self, setpoint_msg: Float64Stamped):
        # Save the received setpoint for control calculations
        self.current_setpoint = setpoint_msg.data

    def on_depth(self, depth_msg: DepthStamped):
        # Save the current depth and compute thrust
        current_depth = depth_msg.depth

        self.get_logger().info(
            f"Hi! I'm your controller running. "
            f'I received a depth of {current_depth} m.',
            throttle_duration_sec=1,
        )

        thrust = self.compute_control_output(current_depth)

        # Use the timestamp of the received depth message
        timestamp = rclpy.time.Time.from_msg(depth_msg.header.stamp)
        self.publish_vertical_thrust(thrust=thrust, timestamp=timestamp)

    def publish_vertical_thrust(self, thrust: float,
                                timestamp: rclpy.time.Time) -> None:
        msg = ActuatorSetpoint()
        # Set vertical thrust only; ignore x and y
        msg.ignore_x = True
        msg.ignore_y = True
        msg.ignore_z = False

        msg.z = thrust

        # Add a timestamp
        msg.header.stamp = timestamp.to_msg()

        self.thrust_pub.publish(msg)

    def compute_control_output(self, current_depth: float) -> float:
        # Fetch current PID parameters
        K_p = self.get_parameter('K_p').value
        K_i = self.get_parameter('K_i').value
        K_d = self.get_parameter('K_d').value

        # Compute PID terms
        error = self.current_setpoint - current_depth
        current_time = self.get_clock().now()
        dt = (current_time - self.last_time).nanoseconds / 1e9

        # Proportional term
        p_term = K_p * error

        # Integral term
        self.integral += error * dt
        i_term = K_i * self.integral

        # Derivative term
        if dt > 0:
            de = error - self.last_error
            d_term = K_d * de / dt
        else:
            d_term = 0.0

        thrust_z = p_term + i_term + d_term

        # Update state
        self.last_error = error
        self.last_time = current_time

        # Ensure setpoint is within allowed range
        if not (-0.8 <= self.current_setpoint <= -0.1):
            return 0.0
        else:
            return thrust_z


def main():
    rclpy.init()
    node = DepthControlNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
